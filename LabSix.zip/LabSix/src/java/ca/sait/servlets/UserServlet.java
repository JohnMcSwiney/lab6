/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ca.sait.servlets;

import ca.sait.models.User;
import ca.sait.services.UserService;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Johnny_McSwiney
 */
public class UserServlet extends HttpServlet {

    User toEdit = null;
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        UserService service = new UserService();
        try{
            List<User> users = service.getAll();
        
            request.setAttribute("users", users);
            if(toEdit != null){
                System.out.println(toEdit.getEmail());
                request.getSession().setAttribute("emailEdit", toEdit.getEmail());
            }
            else{
                this.getServletContext().getRequestDispatcher("/WEB-INF/users.jsp").forward(request, response);  
            }
            
        }catch(Exception ex){
            
        }
        
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action"); // holds email
        String btn = request.getParameter("btn");
        System.out.println(action);
        System.out.println(btn);
        
        UserService service = new UserService();
        
        try {
            List<User> users = service.getAll();
            if(btn.equals("edit")){
            for(User user : users){
                if(user.getEmail().equalsIgnoreCase(action)){
                    toEdit = user;
                    
                    
//                    this.getServletContext().getRequestDispatcher("/WEB-INF/edit.jsp").forward(request, response);
//                    System.out.println("This shouldn't print!");
                    break;
            }
//          String userToEdit = request.getParameter("editBtnValue");
        }
            
        }else if(action.equals("delete")){
            String userToDelete = request.getParameter("deleteBtnValue");
            System.out.println(userToDelete);
        }else{
            
        }
            
        } catch (Exception ex) {
            Logger.getLogger(UserServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        this.getServletContext().getRequestDispatcher("/WEB-INF/users.jsp").forward(request, response);
        
    }


}
